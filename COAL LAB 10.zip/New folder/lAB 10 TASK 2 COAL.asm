
; You may customize this and other start-up templates; 
; The location of this template is c:\emu8086\inc\0_com_template.txt

org 100h

.model small
.stack 100h
.data
arr db 5 dup(?)
max db 0

.code
main:
mov ax, @data
mov ds, ax

mov cx, 5
lea si, arr

input:
mov ah, 1
int 21h
sub al, 30h
mov [si], al
inc si
loop input

lea si, arr
mov al, [si]
mov max, al

mov cx, 4
inc si

check:
mov al, [si]
cmp al, max
jle skip
mov max, al

skip:
inc si
loop check

mov al, max
add al, 30h
mov dl, al
mov ah, 2
int 21h

mov ah, 4ch
int 21h
end main

ret




