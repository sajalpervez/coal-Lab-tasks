
; You may customize this and other start-up templates; 
; The location of this template is c:\emu8086\inc\0_com_template.txt

org 100h

.model small
.stack 100h
.data
arr db 5 dup(?)
count db 0

.code
main:
mov ax, @data
mov ds, ax

mov cx, 5
lea si, arr

input:
mov ah, 1
int 21h
sub al, 30h
mov [si], al
inc si
loop input

mov cx, 5
lea si, arr
mov bl, 0

check_even:
mov al, [si]
and al, 1
jnz skip

inc bl

skip:
inc si
loop check_even

mov al, bl
add al, 30h
mov dl, al
mov ah, 2
int 21h

mov ah, 4ch
int 21h
end main

ret




