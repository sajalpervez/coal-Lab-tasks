
; You may customize this and other start-up templates; 
; The location of this template is c:\emu8086\inc\0_com_template.txt

org 100h

.model small
.stack 100h
.data
arr db 5 dup(?)
sum db 0
msg db 'Enter 5 numbers:$'

.code
main:
mov ax, @data
mov ds, ax

lea dx, msg
mov ah, 9
int 21h

mov cx, 5
lea si, arr

input_loop:
mov ah, 1
int 21h
sub al, 30h
mov [si], al
inc si
loop input_loop

mov cx, 5
lea si, arr
mov al, 0

sum_loop:
add al, [si]
inc si
loop sum_loop

mov sum, al

add al, 30h
mov dl, al
mov ah, 2
int 21h

mov ah, 4ch
int 21h
end main

ret




