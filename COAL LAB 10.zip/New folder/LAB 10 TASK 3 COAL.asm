
; You may customize this and other start-up templates; 
; The location of this template is c:\emu8086\inc\0_com_template.txt

org 100h

.model small
.stack 100h
.data
arr db 5 dup(?)

.code
main:
mov ax, @data
mov ds, ax

mov cx, 5
lea si, arr

input:
mov ah, 1
int 21h
sub al, 30h
mov [si], al
inc si
loop input

lea si, arr
add si, 4
mov cx, 5

reverse:
mov dl, [si]
add dl, 30h
mov ah, 2
int 21h

dec si
loop reverse

mov ah, 4ch
int 21h
end main

ret




