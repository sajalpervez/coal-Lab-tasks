
; You may customize this and other start-up templates; 
; The location of this template is c:\emu8086\inc\0_com_template.txt

org 100h

.model small
.stack 100h
.data
str db 'HELLO$',0

.code
main:
mov ax, @data
mov ds, ax

lea si, str
mov cx, 0

push_loop:
mov al, [si]
cmp al, '$'
je done_push

mov ah, 0
push ax
inc cx
inc si
jmp push_loop

done_push:

; CX me total characters hain
mov ax, cx
add al, 30h
mov dl, al
mov ah, 2
int 21h

mov ah, 4ch
int 21h
end main

ret




