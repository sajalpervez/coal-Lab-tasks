
; You may customize this and other start-up templates; 
; The location of this template is c:\emu8086\inc\0_com_template.txt

org 100h

.model small
.stack 100h
.data
str db 'MADAM$',0
msg1 db 'Palindrome$'
msg2 db 'Not Palindrome$'

.code
main:
mov ax, @data
mov ds, ax

lea si, str
mov cx, 0

; Push all characters
push_loop:
mov al, [si]
cmp al, '$'
je check

mov ah, 0
push ax
inc si
inc cx
jmp push_loop

check:
lea si, str

compare:
cmp cx, 0
je palindrome

mov al, [si]
pop bx
cmp al, bl
jne not_palindrome

inc si
dec cx
jmp compare

palindrome:
lea dx, msg1
mov ah, 9
int 21h
jmp exit

not_palindrome:
lea dx, msg2
mov ah, 9
int 21h

exit:
mov ah, 4ch
int 21h
end main

ret




