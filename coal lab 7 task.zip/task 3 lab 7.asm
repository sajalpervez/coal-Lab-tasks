
; You may customize this and other start-up templates; 
; The location of this template is c:\emu8086\inc\0_com_template.txt

org 100h

.model small
.stack 100h
.data
num db 25
quotient db ?
remainder db ?

.code
main proc

mov ax,@data
mov ds,ax

mov al,num
mov bl,10

div bl        ; AL = quotient , AH = remainder

mov quotient,al
mov remainder,ah

mov ah,4ch
int 21h

main endp
end main

ret




