.model small
.data
num db 03h
cube db ?

.code
mov ax, @data
mov ds, ax

mov al, num
mov bl, num
mul bl

mul num

mov cube, al

mov ah,4ch
int 21h
end