
; You may customize this and other start-up templates; 
; The location of this template is c:\emu8086\inc\0_com_template.txt

org 100h

.model small
.stack 100h
.data
num db 3
result db ?

.code
main proc

mov ax,@data
mov ds,ax

mov al,num     ; AL = number
mov bl,num     ; BL = number

mul bl         ; AL * BL = square
mul bl         ; square * BL = cube

mov result,al  ; store result

mov ah,4ch
int 21h

main endp
end main

ret




